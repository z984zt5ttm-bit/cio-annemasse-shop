const API_URL = "https://script.google.com/macros/s/AKfycbwdPwpXZKo-rDdhrleOZNs-4VyQ5cdTYmzYiq-o9MbTDQeR2WTB-h8MXuEhup4R2V7s/exec";
const ADMIN_TELEGRAM_ID = "8878140883";

const tg = window.Telegram?.WebApp;
if (tg) {
  tg.ready();
  tg.expand();
}

let products = [];
const cart = new Map();

const grid = document.querySelector("#productGrid");
const drawer = document.querySelector("#cartDrawer");
const overlay = document.querySelector("#overlay");

const money = value =>
  new Intl.NumberFormat("fr-FR", {
    style: "currency",
    currency: "EUR"
  }).format(Number(value || 0));

function imagePath(name) {

  if (!name) return "logo.jpeg";

  if (/^https?:\/\//i.test(name)) return name;

  return name.replace(/^assets\//, "");
}

async function loadProducts() {
  grid.innerHTML = '<p class="muted">Chargement du catalogue…</p>';

  try {
    const response = await fetch(`${API_URL}?action=products`, {
      redirect: "follow"
    });
    const data = await response.json();

    if (!data.ok) {
      throw new Error(data.error || "Erreur de chargement");
    }

    products = (data.products || [])
      .filter(product => product.disponible !== false)
      .map(product => ({
        id: String(product.id),
        name: product.nom,
        category: product.categorie,
        price: Number(product.prix || 0),
        unit: "Disponible",
        image: imagePath(product.image),
        desc: product.description || ""
      }));

    renderProducts(document.querySelector("#categoryFilter").value);
    renderCart();
  } catch (error) {
    grid.innerHTML =
      `<p class="status">Impossible de charger les produits : ${error.message}</p>`;
  }
}

function renderProducts(filter = "all") {
  grid.innerHTML = "";

  const visible = products.filter(
    product => filter === "all" || product.category === filter
  );

  if (!visible.length) {
    grid.innerHTML = '<p class="muted">Aucun produit dans cette catégorie.</p>';
    return;
  }

  visible.forEach(product => {
    const card = document.createElement("article");
    card.className = "product";
    card.innerHTML = `
      <div class="product-visual">
        <img src="${product.image}" alt="${product.name}">
      </div>
      <div class="product-body">
        <span class="badge">${product.unit}</span>
        <h3>${product.name}</h3>
        <p>${product.desc}</p>
        <div class="product-meta">
          <span class="price">${money(product.price)}</span>
          <small>18+</small>
        </div>
        <button class="btn primary full add" data-id="${product.id}">
          Ajouter au panier
        </button>
      </div>
    `;
    grid.appendChild(card);
  });

  grid.querySelectorAll(".add").forEach(button => {
    button.addEventListener("click", () => {
      const id = String(button.dataset.id);
      cart.set(id, (cart.get(id) || 0) + 1);
      renderCart();
      openCart();
      tg?.HapticFeedback?.impactOccurred("light");
    });
  });
}

function renderCart() {
  const items = document.querySelector("#cartItems");
  items.innerHTML = "";

  let total = 0;
  let count = 0;

  if (!cart.size) {
    items.innerHTML = '<p class="muted">Votre panier est vide.</p>';
  }

  for (const [id, quantity] of cart.entries()) {
    const product = products.find(item => String(item.id) === String(id));

    if (!product) {
      cart.delete(id);
      continue;
    }

    total += product.price * quantity;
    count += quantity;

    const row = document.createElement("div");
    row.className = "cart-row";
    row.innerHTML = `
      <div>
        <strong>${product.name}</strong>
        <small>${money(product.price)} × ${quantity}</small>
      </div>
      <div class="qty">
        <button data-action="minus" data-id="${id}">−</button>
        <span>${quantity}</span>
        <button data-action="plus" data-id="${id}">+</button>
      </div>
    `;
    items.appendChild(row);
  }

  document.querySelector("#cartTotal").textContent = money(total);
  document.querySelector("#cartCount").textContent = count;

  items.querySelectorAll("button").forEach(button => {
    button.addEventListener("click", () => {
      const id = String(button.dataset.id);
      const next =
        (cart.get(id) || 0) +
        (button.dataset.action === "plus" ? 1 : -1);

      if (next <= 0) {
        cart.delete(id);
      } else {
        cart.set(id, next);
      }

      renderCart();
    });
  });
}

function openCart() {
  drawer.classList.add("open");
  overlay.classList.add("show");
  drawer.setAttribute("aria-hidden", "false");
}

function closeCart() {
  drawer.classList.remove("open");
  overlay.classList.remove("show");
  drawer.setAttribute("aria-hidden", "true");
}

function buildOrder() {
  if (!cart.size) {
    throw new Error("Ajoutez au moins un produit.");
  }

  const name = document.querySelector("#customerName").value.trim();
  const phone = document.querySelector("#customerPhone").value.trim();
  const address = document.querySelector("#customerAddress").value.trim();

  if (!name || !phone || !address) {
    throw new Error("Complétez le nom, le téléphone et le lieu.");
  }

  let total = 0;
  const lines = [];

  for (const [id, quantity] of cart.entries()) {
    const product = products.find(item => String(item.id) === String(id));
    if (!product) continue;

    total += product.price * quantity;
    lines.push(
      `• ${product.name} × ${quantity} — ${money(product.price * quantity)}`
    );
  }

  return {
    name,
    phone,
    address,
    mode: document.querySelector("#deliveryMode").value,
    note: document.querySelector("#customerNote").value.trim(),
    total,
    items: lines
  };
}document.querySelector("#orderBtn").addEventListener("click", async () => {

  const status = document.querySelector("#orderStatus");

  try {

    const order = buildOrder();

    status.textContent = "Envoi de la commande…";

    const response = await fetch(API_URL, {

      method: "POST",

      redirect: "follow",

      headers: {

        "Content-Type": "text/plain;charset=utf-8"

      },

      body: JSON.stringify({

        action: "order",

        order: order

      })

    });

    const result = await response.json();

    if (!result.ok) {

      throw new Error(result.error || "Impossible d’envoyer la commande.");

    }

    status.textContent = "✅ Commande envoyée sur Telegram.";

    cart.clear();

    renderCart();

    tg?.HapticFeedback?.notificationOccurred("success");

  } catch (error) {
status.textContent = "❌ " + error.message;
  }
});

/* ADMINISTRATION */

let adminKey = "";
let adminProducts = [];
let adminOrders = [];

function telegramUserId() {
  return String(tg?.initDataUnsafe?.user?.id || "");
}

function csvToArray(value) {
  return String(value || "")
    .split(/[\n,]+/)
    .map(item => item.trim())
    .filter(Boolean);
}

function safeJson(value, fallback = []) {
  if (Array.isArray(value) || (value && typeof value === "object")) return value;
  if (!value) return fallback;
  try {
    return JSON.parse(value);
  } catch (_) {
    return fallback;
  }
}

function installAdminInterface() {
  const style = document.createElement("style");
  style.textContent = `
    .cio-hidden{display:none!important}
    .cio-admin-button{border:1px solid rgba(141,61,255,.5);background:rgba(141,61,255,.16);color:#fff;border-radius:14px;padding:10px 14px;font-weight:800;margin-right:8px}
    .cio-admin-panel{position:fixed;inset:0;z-index:200;background:rgba(3,2,7,.94);backdrop-filter:blur(14px);padding:14px;overflow:auto}
    .cio-admin-card{width:min(980px,100%);margin:12px auto;background:#080610;border:1px solid rgba(255,255,255,.12);border-radius:24px;padding:18px;color:#fff}
    .cio-admin-head,.cio-admin-toolbar,.cio-admin-actions,.cio-admin-tabs{display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap}
    .cio-admin-tabs{justify-content:flex-start;margin:16px 0}
    .cio-tab{background:#17102a;color:#fff;border:1px solid rgba(255,255,255,.12)!important}
    .cio-tab.active{background:linear-gradient(135deg,#00eaff,#8d3dff);color:#07050d}
    .cio-admin-list{display:grid;gap:12px;margin-top:16px}
    .cio-admin-item{display:grid;grid-template-columns:72px 1fr auto;gap:12px;align-items:center;border:1px solid rgba(255,255,255,.12);border-radius:16px;padding:12px}
    .cio-admin-item img,.cio-admin-item video{width:72px;height:72px;object-fit:cover;border-radius:12px;background:#111}
    .cio-admin-item h3{margin:0 0 4px}.cio-admin-item p{margin:0;color:#b5abc8;font-size:13px}
    .cio-admin-item button,.cio-admin-card button{border:0;border-radius:12px;padding:10px 12px;font-weight:800}
    .cio-edit{background:#ffd54a;color:#17120a}.cio-delete{background:#e95555;color:#fff;margin-top:6px}
    .cio-primary{background:linear-gradient(135deg,#00eaff,#8d3dff);color:#07050d}.cio-secondary{background:#17102a;color:#fff;border:1px solid rgba(255,255,255,.12)!important}
    .cio-admin-form{display:grid;gap:12px;margin-top:18px;padding-top:18px;border-top:1px solid rgba(255,255,255,.12)}
    .cio-admin-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px}
    .cio-admin-form label{display:grid;gap:6px;color:#b5abc8}.cio-admin-form input,.cio-admin-form select,.cio-admin-form textarea{width:100%;background:#0a0712;border:1px solid rgba(255,255,255,.12);color:#fff;border-radius:13px;padding:12px}
    .cio-check{display:flex!important;align-items:center;gap:8px}.cio-check input{width:auto}.cio-status{color:#00eaff;margin-top:10px;white-space:pre-wrap}
    .cio-kpis{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px;margin-top:14px}.cio-kpi{border:1px solid rgba(255,255,255,.12);border-radius:16px;padding:14px;background:#0d0917}.cio-kpi small{color:#b5abc8}.cio-kpi strong{display:block;font-size:22px;margin-top:6px;color:#b44cff}
    .cio-order{display:grid;gap:8px}.cio-order select{background:#0a0712;color:#fff;border:1px solid rgba(255,255,255,.12);border-radius:10px;padding:8px}
    @media(max-width:700px){.cio-admin-grid,.cio-kpis{grid-template-columns:1fr}.cio-admin-item{grid-template-columns:56px 1fr}.cio-admin-item img,.cio-admin-item video{width:56px;height:56px}.cio-admin-item-controls{grid-column:1/-1;display:grid;grid-template-columns:1fr 1fr;gap:8px}.cio-delete{margin-top:0}}
  `;
  document.head.appendChild(style);

  const cartButton = document.querySelector("#cartToggle");
  if (!cartButton || document.querySelector("#cioAdminButton")) return;

  const adminButton = document.createElement("button");
  adminButton.id = "cioAdminButton";
  adminButton.className = "cio-admin-button";
  adminButton.textContent = "⚙️ Admin";
  cartButton.parentNode.insertBefore(adminButton, cartButton);

  const panel = document.createElement("section");
  panel.id = "cioAdminPanel";
  panel.className = "cio-admin-panel cio-hidden";
  panel.innerHTML = `
    <div class="cio-admin-card">
      <div class="cio-admin-head">
        <div><p class="eyebrow">ADMINISTRATION</p><h2>Gestion de la boutique</h2></div>
        <button id="cioAdminClose" class="cio-secondary">Fermer</button>
      </div>
      <div class="cio-admin-tabs">
        <button class="cio-tab active" data-tab="products">Produits</button>
        <button class="cio-tab" data-tab="orders">Commandes</button>
        <button class="cio-tab" data-tab="accounting">Comptabilité</button>
      </div>
      <div id="cioAdminMessage" class="cio-status"></div>

      <section id="cioTabProducts">
        <div class="cio-admin-toolbar">
          <button id="cioAdminRefresh" class="cio-secondary">Actualiser</button>
          <button id="cioAdminAdd" class="cio-primary">Ajouter un produit</button>
        </div>
        <div id="cioAdminList" class="cio-admin-list"></div>
        <div id="cioAdminForm" class="cio-admin-form cio-hidden">
          <h3 id="cioAdminFormTitle">Produit</h3>
          <input id="cioProductId" type="hidden">
          <div class="cio-admin-grid">
            <label>Nom<input id="cioProductName" type="text"></label>
            <label>Catégorie
              <select id="cioProductCategory">
                <option value="fleurs">Fleurs</option><option value="resines">Résines</option><option value="puffs">Puffs</option><option value="cali plates">Cali Plates</option><option value="frozen giants">Frozen Giants</option><option value="collections">Collections</option>
              </select>
            </label>
            <label>Prix<input id="cioProductPrice" type="number" min="0" step="0.01"></label>
            <label>Image principale<input id="cioProductImage" type="text" placeholder="URL ou nom_image.jpeg"></label>
          </div>
          <label>Photos supplémentaires (une URL par ligne)<textarea id="cioProductImages" rows="3" placeholder="https://.../photo1.jpg"></textarea></label>
          <label>Vidéos (une URL par ligne)<textarea id="cioProductVideos" rows="3" placeholder="https://.../video.mp4"></textarea></label>
          <label>Variantes JSON (optionnel)<textarea id="cioProductVariants" rows="4" placeholder='[{"nom":"10g","prix":120,"stock":5}]'></textarea></label>
          <label>Description<textarea id="cioProductDescription" rows="4"></textarea></label>
          <label class="cio-check"><input id="cioProductAvailable" type="checkbox" checked>Disponible</label>
          <div class="cio-admin-actions"><button id="cioAdminCancel" class="cio-secondary">Annuler</button><button id="cioAdminSave" class="cio-primary">Enregistrer</button></div>
        </div>
      </section>

      <section id="cioTabOrders" class="cio-hidden">
        <div class="cio-admin-toolbar"><button id="cioOrdersRefresh" class="cio-secondary">Actualiser les commandes</button></div>
        <div id="cioOrdersList" class="cio-admin-list"></div>
      </section>

      <section id="cioTabAccounting" class="cio-hidden">
        <div class="cio-admin-toolbar"><button id="cioAccountingRefresh" class="cio-secondary">Actualiser la comptabilité</button></div>
        <div id="cioAccountingKpis" class="cio-kpis"></div>
        <div id="cioAccountingList" class="cio-admin-list"></div>
      </section>
    </div>`;
  document.body.appendChild(panel);

  adminButton.addEventListener("click", openAdmin);
  document.querySelector("#cioAdminClose").addEventListener("click", closeAdmin);
  document.querySelector("#cioAdminRefresh").addEventListener("click", refreshAdmin);
  document.querySelector("#cioAdminAdd").addEventListener("click", () => showAdminForm());
  document.querySelector("#cioAdminCancel").addEventListener("click", () => document.querySelector("#cioAdminForm").classList.add("cio-hidden"));
  document.querySelector("#cioAdminSave").addEventListener("click", saveAdminProduct);
  document.querySelector("#cioOrdersRefresh").addEventListener("click", loadAdminOrders);
  document.querySelector("#cioAccountingRefresh").addEventListener("click", renderAccounting);
  document.querySelectorAll(".cio-tab").forEach(button => button.addEventListener("click", () => switchAdminTab(button.dataset.tab)));
}

function switchAdminTab(tab) {
  document.querySelectorAll(".cio-tab").forEach(button => button.classList.toggle("active", button.dataset.tab === tab));
  document.querySelector("#cioTabProducts").classList.toggle("cio-hidden", tab !== "products");
  document.querySelector("#cioTabOrders").classList.toggle("cio-hidden", tab !== "orders");
  document.querySelector("#cioTabAccounting").classList.toggle("cio-hidden", tab !== "accounting");
  if (tab === "orders") loadAdminOrders();
  if (tab === "accounting") renderAccounting();
}

function openAdmin() {
  document.querySelector("#cioAdminPanel").classList.remove("cio-hidden");
  if (!adminKey) adminKey = prompt("Entre ton code secret administrateur :") || "";
  if (!adminKey) {
    document.querySelector("#cioAdminMessage").textContent = "Code administrateur obligatoire.";
    return;
  }
  refreshAdmin();
}

function closeAdmin() {
  document.querySelector("#cioAdminPanel").classList.add("cio-hidden");
  document.querySelector("#cioAdminForm").classList.add("cio-hidden");
}

async function adminPost(payload) {
  const response = await fetch(API_URL, {
    method: "POST", redirect: "follow", headers: {"Content-Type":"text/plain;charset=utf-8"},
    body: JSON.stringify({...payload, adminKey, telegramId: telegramUserId()})
  });
  return response.json();
}

async function adminGet(action) {
  const url = `${API_URL}?action=${encodeURIComponent(action)}&adminKey=${encodeURIComponent(adminKey)}&telegramId=${encodeURIComponent(telegramUserId())}`;
  const response = await fetch(url, {redirect:"follow"});
  return response.json();
}

async function refreshAdmin() {
  const message = document.querySelector("#cioAdminMessage");
  message.textContent = "Chargement…";
  try {
    const response = await fetch(`${API_URL}?action=products`, {redirect:"follow"});
    const data = await response.json();
    if (!data.ok) throw new Error(data.error || "Erreur");
    adminProducts = data.products || [];
    renderAdminList(adminProducts);
    message.textContent = "";
  } catch (error) { message.textContent = error.message; }
}

function firstMedia(product) {
  const extras = Array.isArray(product.images) ? product.images : safeJson(product.images, csvToArray(product.images));
  return imagePath(product.image || extras[0] || "logo.jpeg");
}

function renderAdminList(list) {
  const container = document.querySelector("#cioAdminList");
  container.innerHTML = "";
  list.forEach(product => {
    const item = document.createElement("div");
    item.className = "cio-admin-item";
    item.innerHTML = `<img src="${firstMedia(product)}" alt=""><div><h3>${product.nom || "Sans nom"}</h3><p>${product.categorie || ""} • ${money(product.prix)} • ${product.disponible ? "Disponible" : "Indisponible"}</p></div><div class="cio-admin-item-controls"><button class="cio-edit" data-id="${product.id}">Modifier</button><button class="cio-delete" data-id="${product.id}">Supprimer</button></div>`;
    container.appendChild(item);
  });
  container.querySelectorAll(".cio-edit").forEach(button => button.addEventListener("click", () => showAdminForm(list.find(item => String(item.id) === String(button.dataset.id)))));
  container.querySelectorAll(".cio-delete").forEach(button => button.addEventListener("click", async () => {
    if (!confirm("Supprimer ce produit ?")) return;
    const message = document.querySelector("#cioAdminMessage"); message.textContent = "Suppression…";
    try {
      const result = await adminPost({action:"delete", id:String(button.dataset.id)});
      if (!result.ok) throw new Error(result.error || "Accès administrateur refusé");
      await refreshAdmin(); await loadProducts();
    } catch (error) { message.textContent = error.message; }
  }));
}

function showAdminForm(product = null) {
  document.querySelector("#cioAdminForm").classList.remove("cio-hidden");
  document.querySelector("#cioAdminFormTitle").textContent = product ? "Modifier le produit" : "Ajouter un produit";
  document.querySelector("#cioProductId").value = product?.id || "";
  document.querySelector("#cioProductName").value = product?.nom || "";
  document.querySelector("#cioProductCategory").value = product?.categorie || "fleurs";
  document.querySelector("#cioProductPrice").value = product?.prix ?? "";
  document.querySelector("#cioProductImage").value = product?.image || "";
  document.querySelector("#cioProductImages").value = (Array.isArray(product?.images) ? product.images : safeJson(product?.images, csvToArray(product?.images))).join("\n");
  document.querySelector("#cioProductVideos").value = (Array.isArray(product?.videos) ? product.videos : safeJson(product?.videos, csvToArray(product?.videos))).join("\n");
  document.querySelector("#cioProductVariants").value = product?.variants ? (typeof product.variants === "string" ? product.variants : JSON.stringify(product.variants, null, 2)) : "";
  document.querySelector("#cioProductDescription").value = product?.description || "";
  document.querySelector("#cioProductAvailable").checked = product ? Boolean(product.disponible) : true;
}

async function saveAdminProduct() {
  const message = document.querySelector("#cioAdminMessage");
  const rawVariants = document.querySelector("#cioProductVariants").value.trim();
  let variants = [];
  if (rawVariants) {
    try { variants = JSON.parse(rawVariants); }
    catch (_) { message.textContent = "Le champ Variantes JSON n’est pas valide."; return; }
  }
  const product = {
    id: document.querySelector("#cioProductId").value || undefined,
    nom: document.querySelector("#cioProductName").value.trim(),
    categorie: document.querySelector("#cioProductCategory").value,
    prix: Number(document.querySelector("#cioProductPrice").value),
    image: document.querySelector("#cioProductImage").value.trim(),
    images: csvToArray(document.querySelector("#cioProductImages").value),
    videos: csvToArray(document.querySelector("#cioProductVideos").value),
    variants,
    description: document.querySelector("#cioProductDescription").value.trim(),
    disponible: document.querySelector("#cioProductAvailable").checked
  };
  if (!product.nom || !Number.isFinite(product.prix)) { message.textContent = "Nom et prix obligatoires."; return; }
  message.textContent = "Enregistrement…";
  try {
    const result = await adminPost({action:product.id ? "update" : "add", product});
    if (!result.ok) throw new Error(result.error || "Accès administrateur refusé");
    document.querySelector("#cioAdminForm").classList.add("cio-hidden");
    await refreshAdmin(); await loadProducts(); message.textContent = "Produit enregistré.";
  } catch (error) { message.textContent = error.message; }
}

async function loadAdminOrders() {
  const container = document.querySelector("#cioOrdersList");
  const message = document.querySelector("#cioAdminMessage");
  container.innerHTML = ""; message.textContent = "Chargement des commandes…";
  try {
    const data = await adminGet("orders");
    if (!data.ok) throw new Error(data.error || "La partie commandes doit être activée dans Code.gs.");
    adminOrders = data.orders || [];
    if (!adminOrders.length) container.innerHTML = '<p class="muted">Aucune commande.</p>';
    adminOrders.forEach(order => {
      const row = document.createElement("div"); row.className = "cio-admin-item cio-order";
      row.innerHTML = `<div><h3>${order.orderNumber || order.numero || "Commande"}</h3><p>${order.name || order.nom || "Client"} • ${money(order.total)} • ${order.status || "Nouvelle"}</p><p>${order.phone || ""} ${order.address || ""}</p></div>`;
      container.appendChild(row);
    });
    message.textContent = "";
  } catch (error) { message.textContent = error.message; }
}

function renderAccounting() {
  const kpis = document.querySelector("#cioAccountingKpis");
  const list = document.querySelector("#cioAccountingList");
  const completed = adminOrders.filter(order => !/annul/i.test(String(order.status || "")));
  const revenue = completed.reduce((sum, order) => sum + Number(order.total || 0), 0);
  const todayKey = new Date().toISOString().slice(0,10);
  const todayRevenue = completed.filter(order => String(order.createdAt || order.date || "").slice(0,10) === todayKey).reduce((sum, order) => sum + Number(order.total || 0), 0);
  kpis.innerHTML = `<div class="cio-kpi"><small>Chiffre d’affaires</small><strong>${money(revenue)}</strong></div><div class="cio-kpi"><small>Aujourd’hui</small><strong>${money(todayRevenue)}</strong></div><div class="cio-kpi"><small>Commandes</small><strong>${completed.length}</strong></div><div class="cio-kpi"><small>Panier moyen</small><strong>${money(completed.length ? revenue/completed.length : 0)}</strong></div>`;
  list.innerHTML = adminOrders.length ? '<p class="muted">La comptabilité est calculée à partir des commandes chargées.</p>' : '<p class="muted">Charge d’abord les commandes dans l’onglet Commandes.</p>';
}

// Le bouton Admin reste visible même hors de Telegram. La clé ADMIN_KEY du serveur protège les modifications.
installAdminInterface();

document.querySelector("#ageYes").addEventListener("click", () => {
  document.querySelector("#ageGate").classList.add("hidden");
});

document.querySelector("#ageNo").addEventListener("click", () => {
  document.querySelector(".gate-card").innerHTML =
    "<h1>Accès refusé</h1><p>Cette boutique est réservée aux personnes majeures.</p>";
});

document.querySelector("#cartToggle").addEventListener("click", openCart);
document.querySelector("#cartClose").addEventListener("click", closeCart);
overlay.addEventListener("click", closeCart);

document
  .querySelector("#categoryFilter")
  .addEventListener("change", event => renderProducts(event.target.value));

document.querySelector("#contactBtn").addEventListener("click", () => {
  tg?.openTelegramLink?.("https://t.me/Ciogeneve_bot") ||
    alert("Contact Telegram : @Ciogeneve_bot");
});

loadProducts();
